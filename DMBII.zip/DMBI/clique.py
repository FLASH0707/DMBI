import csv
import numpy as np

class CLIQUE:
    def __init__(self, grid_size=5):
        self.grid_size = grid_size
        self.grid_clusters = {}
    
    def fit(self, X):
        for i in range(len(X)):
            grid_cell = tuple(int(val // self.grid_size) for val in X[i])
            if grid_cell not in self.grid_clusters:
                self.grid_clusters[grid_cell] = []
            self.grid_clusters[grid_cell].append(i)

    def predict(self, X):
        labels = [-1] * len(X)
        cluster_id = 0
        for cell, indices in self.grid_clusters.items():
            for idx in indices:
                labels[idx] = cluster_id
            cluster_id += 1
        return labels

def load_csv(filename):
    X = []
    with open(filename, 'r') as f:
        reader = csv.reader(f)
        for row in reader:
            X.append(list(map(float, row)))
    return np.array(X)

if __name__ == "__main__":
    filename = "clique.csv"  # Automatically uses CSV from the same directory
    X = load_csv(filename)
    model = CLIQUE(grid_size=5)
    model.fit(X)
    labels = model.predict(X)
    print("Predicted cluster labels:", labels)
