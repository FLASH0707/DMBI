import pandas as pd
import numpy as np

# Define the Decision Tree Class
class DecisionTree:
    def __init__(self):
        self.tree = None

    # Gini Index Calculation
    def gini(self, y):
        classes, counts = np.unique(y, return_counts=True)
        prob = counts / len(y)
        return 1 - np.sum(prob ** 2)

    # Best Split Calculation (Find feature and threshold to split)
    def best_split(self, X, y):
        best_gini = float('inf')
        best_split = None
        for feature_index in range(X.shape[1]):
            thresholds = np.unique(X[:, feature_index])
            for threshold in thresholds:
                left_mask = X[:, feature_index] <= threshold
                right_mask = ~left_mask
                left_y = y[left_mask]
                right_y = y[right_mask]

                gini_left = self.gini(left_y)
                gini_right = self.gini(right_y)
                gini_split = (len(left_y) / len(y)) * gini_left + (len(right_y) / len(y)) * gini_right

                if gini_split < best_gini:
                    best_gini = gini_split
                    best_split = {
                        'feature_index': feature_index,
                        'threshold': threshold,
                        'left_y': left_y,
                        'right_y': right_y,
                        'left_mask': left_mask,
                        'right_mask': right_mask
                    }
        return best_split

    # Building the Decision Tree (Recursive)
    def build_tree(self, X, y, depth=0, max_depth=5):
        if len(np.unique(y)) == 1:
            return y[0]  # Return leaf value if all examples are the same
        if depth >= max_depth:
            return np.bincount(y).argmax()  # Majority class

        best_split = self.best_split(X, y)
        if best_split is None:
            return np.bincount(y).argmax()  # Majority class if no good split

        left_tree = self.build_tree(X[best_split['left_mask']], best_split['left_y'], depth + 1, max_depth)
        right_tree = self.build_tree(X[best_split['right_mask']], best_split['right_y'], depth + 1, max_depth)

        return {
            'feature_index': best_split['feature_index'],
            'threshold': best_split['threshold'],
            'left': left_tree,
            'right': right_tree
        }

    # Prediction (traversing the tree)
    def predict_sample(self, x, tree):
        if isinstance(tree, dict):
            if x[tree['feature_index']] <= tree['threshold']:
                return self.predict_sample(x, tree['left'])
            else:
                return self.predict_sample(x, tree['right'])
        else:
            return tree

    def fit(self, X, y):
        self.tree = self.build_tree(X, y)

    def predict(self, X):
        return [self.predict_sample(x, self.tree) for x in X]

    # Function to print the tree in a readable format
    def print_tree(self, tree=None, depth=0):
        if tree is None:
            tree = self.tree

        if isinstance(tree, dict):
            print(f"{'  ' * depth}Feature {tree['feature_index']} <= {tree['threshold']} ?")
            print(f"{'  ' * depth}Left:")
            self.print_tree(tree['left'], depth + 1)
            print(f"{'  ' * depth}Right:")
            self.print_tree(tree['right'], depth + 1)
        else:
            print(f"{'  ' * depth}Predict: {tree}")

# Load data
df = pd.read_csv('car_data.csv')

# Encode categorical columns
df['OwnsHouse'] = df['OwnsHouse'].map({'No': 0, 'Yes': 1})
df['BuysSportsCar'] = df['BuysSportsCar'].map({'No': 0, 'Yes': 1})

# Features and Target
X = df[['Age', 'Income', 'OwnsHouse']].values
y = df['BuysSportsCar'].values

# Train Decision Tree
model = DecisionTree()
model.fit(X, y)

# Print the decision tree
print("Decision Tree Structure:")
model.print_tree()

# Predict on new input
test_data = np.array([[30, 65000, 0]])  # Example: Age = 30, Income = 65000, OwnsHouse = No
prediction = model.predict(test_data)
predicted_label = 'Yes' if prediction[0] == 1 else 'No'
print(f'Prediction for test input: {predicted_label}')  # Output: Yes or No
