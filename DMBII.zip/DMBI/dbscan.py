# dbscan_csv.py
import csv
import numpy as np
from sklearn.metrics.pairwise import euclidean_distances

class DBSCAN:
    def __init__(self, eps=0.5, min_samples=5):
        self.eps = eps
        self.min_samples = min_samples
        self.labels = None

    def fit(self, X):
        n_samples = len(X)
        self.labels = [-1] * n_samples  # -1 means noise
        visited = [False] * n_samples
        cluster_id = 0

        for i in range(n_samples):
            if visited[i]:
                continue
            visited[i] = True
            neighbors = self._region_query(X, i)
            if len(neighbors) < self.min_samples:
                self.labels[i] = -1  # noise
            else:
                self._expand_cluster(X, i, neighbors, cluster_id, visited)
                cluster_id += 1

    def _expand_cluster(self, X, i, neighbors, cluster_id, visited):
        self.labels[i] = cluster_id
        j = 0
        while j < len(neighbors):
            point = neighbors[j]
            if not visited[point]:
                visited[point] = True
                new_neighbors = self._region_query(X, point)
                if len(new_neighbors) >= self.min_samples:
                    neighbors += new_neighbors
            if self.labels[point] == -1:
                self.labels[point] = cluster_id
            elif self.labels[point] == -1:
                self.labels[point] = cluster_id
            j += 1

    def _region_query(self, X, i):
        distances = euclidean_distances(X[i:i+1], X)[0]
        return [idx for idx, dist in enumerate(distances) if dist < self.eps]

    def predict(self):
        return self.labels

def load_csv(filename):
    X = []
    with open(filename, 'r') as f:
        reader = csv.reader(f)
        for row in reader:
            X.append(list(map(float, row)))
    return np.array(X)

if __name__ == "__main__":
    filename = "dbscan.csv"  # Automatically use data.csv in the same directory
    X = load_csv(filename)
    model = DBSCAN(eps=1.0, min_samples=3)
    model.fit(X)
    labels = model.predict()
    print("Predicted labels:", labels)
