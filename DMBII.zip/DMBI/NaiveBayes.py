import pandas as pd
import numpy as np

# Load dataset
df = pd.read_csv('basyen.csv')

# Separate features and target
features = ['Outlook', 'Temperature', 'Humidity', 'Windy']
target = 'Play'

# Calculate prior probabilities
def calculate_prior(df, target):
    return df[target].value_counts(normalize=True).to_dict()

# Calculate likelihood probabilities
def calculate_likelihood(df, features, target):
    likelihood = {}
    target_values = df[target].unique()
    
    # Loop through each feature
    for feature in features:
        likelihood[feature] = {}
        
        # Loop through each value of the feature
        for feature_val in df[feature].unique():
            likelihood[feature][feature_val] = {}
            
            # Loop through each target class
            for t_val in target_values:
                # Count the occurrences of (feature_val, target_class)
                num = len(df[(df[feature] == feature_val) & (df[target] == t_val)])
                
                # Count the occurrences of the target class
                denom = len(df[df[target] == t_val])
                
                # Calculate the likelihood: P(feature_value | target_class)
                likelihood[feature][feature_val][t_val] = num / denom if denom != 0 else 0
    return likelihood

# Predict using Naive Bayes
def predict(instance, prior, likelihood, target_values):
    probs = {}
    
    # For each target class, calculate the posterior probability
    for t_val in target_values:
        prob = prior[t_val]
        
        # Multiply prior by the likelihoods of the feature values
        for feature, feature_val in instance.items():
            prob *= likelihood[feature].get(feature_val, {}).get(t_val, 0)
        
        probs[t_val] = prob
    
    # Return the class with the highest posterior probability
    return max(probs, key=probs.get)

# Train model
prior = calculate_prior(df, target)
likelihood = calculate_likelihood(df, features, target)
target_values = df[target].unique()

# Example test instance
test_instance = {'Outlook': 'Sunny', 'Temperature': 'Cool', 'Humidity': 'High', 'Windy': 'True'}

# Predict result
result = predict(test_instance, prior, likelihood, target_values)
print(f'Prediction: {result}')
