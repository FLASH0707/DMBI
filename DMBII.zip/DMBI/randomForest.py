import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from collections import Counter

# Load the dataset
df = pd.read_csv("RandomForest.csv")

# Separate features and target variable
X = df[['study_hours', 'sleep_hours']].values
y = df['passed'].values

# Train-test split (70% training, 30% testing)
def train_test_split_manual(X, y, test_size=0.3, random_state=42):
    np.random.seed(random_state)
    indices = np.random.permutation(len(X))
    test_size = int(len(X) * test_size)
    train_indices = indices[:-test_size]
    test_indices = indices[-test_size:]
    return X[train_indices], X[test_indices], y[train_indices], y[test_indices]

X_train, X_test, y_train, y_test = train_test_split_manual(X, y, test_size=0.3)

# Utility functions to calculate gini index and entropy
def gini_impurity(y):
    class_counts = Counter(y)
    total = len(y)
    gini = 1 - sum((count / total) ** 2 for count in class_counts.values())
    return gini

def entropy(y):
    class_counts = Counter(y)
    total = len(y)
    return -sum((count / total) * np.log2(count / total) for count in class_counts.values())

# Decision Tree Classifier Implementation
class DecisionTree:
    def __init__(self, max_depth=None):
        self.max_depth = max_depth

    def fit(self, X, y):
        self.tree = self._build_tree(X, y)

    def _build_tree(self, X, y, depth=0):
        num_samples, num_features = X.shape
        unique_classes = np.unique(y)
        # If all samples belong to the same class or max depth reached
        if len(unique_classes) == 1 or (self.max_depth is not None and depth >= self.max_depth):
            return unique_classes[0]

        best_split = self._find_best_split(X, y)
        if best_split is None:
            return Counter(y).most_common(1)[0][0]

        left_X, left_y, right_X, right_y = self._split(X, y, best_split)
        left_tree = self._build_tree(left_X, left_y, depth + 1)
        right_tree = self._build_tree(right_X, right_y, depth + 1)

        return {"split": best_split, "left": left_tree, "right": right_tree}

    def _find_best_split(self, X, y):
        best_split = None
        best_gini = float("inf")
        num_samples, num_features = X.shape
        for feature_idx in range(num_features):
            feature_values = np.unique(X[:, feature_idx])
            for value in feature_values:
                left_mask = X[:, feature_idx] <= value
                right_mask = ~left_mask
                left_y = y[left_mask]
                right_y = y[right_mask]
                gini_left = gini_impurity(left_y)
                gini_right = gini_impurity(right_y)
                gini = (len(left_y) * gini_left + len(right_y) * gini_right) / num_samples
                if gini < best_gini:
                    best_gini = gini
                    best_split = (feature_idx, value)
        return best_split

    def _split(self, X, y, split):
        feature_idx, value = split
        left_mask = X[:, feature_idx] <= value
        right_mask = ~left_mask
        return X[left_mask], y[left_mask], X[right_mask], y[right_mask]

    def predict(self, X):
        return [self._predict_one(x) for x in X]

    def _predict_one(self, x):
        tree = self.tree
        while isinstance(tree, dict):
            feature_idx, value = tree["split"]
            if x[feature_idx] <= value:
                tree = tree["left"]
            else:
                tree = tree["right"]
        return tree

# Random Forest Classifier Implementation
class RandomForest:
    def __init__(self, n_estimators=10, max_depth=None):
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.trees = []

    def fit(self, X, y):
        for _ in range(self.n_estimators):
            tree = DecisionTree(max_depth=self.max_depth)
            tree.fit(X, y)
            self.trees.append(tree)

    def predict(self, X):
        tree_predictions = np.zeros((len(X), self.n_estimators))
        for i, tree in enumerate(self.trees):
            tree_predictions[:, i] = tree.predict(X)
        # Majority vote for final prediction
        return [Counter(tree_predictions[i, :]).most_common(1)[0][0] for i in range(len(X))]

# Training the Random Forest model
rf = RandomForest(n_estimators=100, max_depth=3)
rf.fit(X_train, y_train)

# Make predictions
y_pred = rf.predict(X_test)

# Ensure both y_test and y_pred are integers
y_test_int = np.array(y_test, dtype=int)
y_pred_int = np.array(y_pred, dtype=int)

# Evaluate the model
def accuracy(y_true, y_pred):
    return np.sum(y_true == y_pred) / len(y_true)

def confusion_matrix(y_true, y_pred):
    cm = np.zeros((2, 2), dtype=int)
    for true, pred in zip(y_true, y_pred):
        cm[true, pred] += 1
    return cm

accuracy_score = accuracy(y_test_int, y_pred_int)
conf_matrix = confusion_matrix(y_test_int, y_pred_int)

print("Accuracy:", accuracy_score)
print("Confusion Matrix:\n", conf_matrix)

# Visualizing one tree from the Random Forest
def plot_tree_manually(tree, feature_names, class_names, depth=0):
    if isinstance(tree, dict):
        feature_idx, value = tree["split"]
        print(f"{'  ' * depth}Feature: {feature_names[feature_idx]} <= {value}")
        print(f"{'  ' * depth}Left:")
        plot_tree_manually(tree["left"], feature_names, class_names, depth + 1)
        print(f"{'  ' * depth}Right:")
        plot_tree_manually(tree["right"], feature_names, class_names, depth + 1)
    else:
        print(f"{'  ' * depth}Class: {class_names[tree]}")

# Plot the first decision tree
plt.figure(figsize=(10, 8))
print("Decision Tree Visualization:")
plot_tree_manually(rf.trees[0].tree, ['study_hours', 'sleep_hours'], ['Fail', 'Passed'])
