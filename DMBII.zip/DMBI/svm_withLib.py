import numpy as np
import pandas as pd

# Load the dataset
df = pd.read_csv('svm_dataset.csv')

# Split data into features and labels
X = df[['feature1', 'feature2']].values
y = df['label'].values

# Convert labels to +1 and -1 for SVM
y = np.where(y == 0, -1, 1)

# Train-test split manually (70% training, 30% test)
train_size = int(0.7 * len(X))
X_train, X_test = X[:train_size], X[train_size:]
y_train, y_test = y[:train_size], y[train_size:]

# Initialize SVM parameters
n_features = X_train.shape[1]
n_samples = X_train.shape[0]
learning_rate = 0.01
epochs = 1000
lambda_param = 0.01

# Initialize weights and bias
weights = np.zeros(n_features)
bias = 0

# Function to compute the hinge loss
def hinge_loss(X, y, weights, bias, lambda_param):
    loss = 0
    for i in range(X.shape[0]):
        margin = y[i] * (np.dot(X[i], weights) + bias)
        loss += max(0, 1 - margin)  # Hinge loss
    return 0.5 * np.dot(weights, weights) + lambda_param * loss

# Training the SVM model using gradient descent
for epoch in range(epochs):
    for i in range(n_samples):
        margin = y_train[i] * (np.dot(X_train[i], weights) + bias)
        
        # Update rule for weights and bias
        if margin >= 1:
            weights -= learning_rate * lambda_param * weights  # Regularization term
        else:
            weights -= learning_rate * (lambda_param * weights - y_train[i] * X_train[i])
            bias -= learning_rate * (-y_train[i])  # Bias update

    # Calculate the hinge loss (optional: to monitor convergence)
    if epoch % 100 == 0:
        loss = hinge_loss(X_train, y_train, weights, bias, lambda_param)
        print(f"Epoch {epoch}, Loss: {loss}")

# Predict function for the test set
def predict(X, weights, bias):
    return np.sign(np.dot(X, weights) + bias)

# Predict on test data
y_pred = predict(X_test, weights, bias)

# Evaluate the model (Accuracy calculation)
accuracy = np.mean(y_pred == y_test)
print("Accuracy:", accuracy)
print("Predictions:", y_pred)
print("True labels:", y_test)
