import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

# Load data from CSV
data = pd.read_csv('kmeans.csv')  # Replace with your actual CSV filename
inputs = data[['feature1', 'feature2']].values  # Extract features

# Standardize the features (scaling)
scaler = StandardScaler()
inputs_scaled = scaler.fit_transform(inputs)

# Number of clusters (you can experiment with different values)
n_clusters = 3

# Apply KMeans clustering
kmeans = KMeans(n_clusters=n_clusters, random_state=42)
kmeans.fit(inputs_scaled)

# Get cluster centers and labels
cluster_centers = kmeans.cluster_centers_
labels = kmeans.labels_

# Add the cluster labels to the original data
data['cluster'] = labels

# Print cluster centers and the data with cluster labels
print("Cluster Centers:")
print(cluster_centers)
print("\nData with cluster labels:")
print(data)

# Visualization: Plot the clustered data points
plt.figure(figsize=(12, 8))  # Larger figure for better visualization

# Create a scatter plot for data points with colors based on their cluster label
scatter = plt.scatter(data['feature1'], data['feature2'], c=data['cluster'], cmap='Set2', s=100, alpha=0.7, edgecolors='w', marker='o')

# Plot centroids as red 'X'
plt.scatter(cluster_centers[:, 0], cluster_centers[:, 1], s=300, c='red', marker='X', label='Centroids', edgecolors='black', linewidths=2)

# Highlight the clusters with convex hulls
from scipy.spatial import ConvexHull

for i in range(n_clusters):
    cluster_data = data[data['cluster'] == i]
    points = cluster_data[['feature1', 'feature2']].values
    hull = ConvexHull(points)
    plt.fill(points[hull.vertices, 0], points[hull.vertices, 1], alpha=0.2, label=f'Cluster {i+1}')

# Enhance the graph with titles, labels, and grid
plt.xlabel('Feature 1', fontsize=14)
plt.ylabel('Feature 2', fontsize=14)
plt.title('K-Means Clustering with Centroids and Cluster Regions', fontsize=16)
plt.legend(fontsize=12)
plt.grid(True, linestyle='--', alpha=0.7)

# Display the plot
plt.colorbar(scatter, label='Cluster ID')
plt.show()
