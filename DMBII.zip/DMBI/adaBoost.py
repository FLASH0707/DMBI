import numpy as np
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix

# Load the dataset
df = pd.read_csv('adaboost_dataset.csv')
X = df[['feature1', 'feature2']].values
y = df['label'].values

# Split dataset into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Convert labels to -1, 1 for AdaBoost
y_train = np.where(y_train == 0, -1, 1)
y_test = np.where(y_test == 0, -1, 1)

# Initialize parameters
n_estimators = 10  # Number of classifiers
n_samples = len(X_train)
weights = np.ones(n_samples) / n_samples  # Sample weights

# Function to train AdaBoost model
def adaboost(X_train, y_train, n_estimators):
    classifiers = []
    alphas = []
    sample_weights = np.ones(len(X_train)) / len(X_train)  # Initialize weights for each sample
    
    for _ in range(n_estimators):
        # Train a base model (weak classifier)
        clf = DecisionTreeClassifier(max_depth=1)
        clf.fit(X_train, y_train, sample_weight=sample_weights)  # Pass sample weights correctly
        
        # Predict with the weak classifier
        y_pred = clf.predict(X_train)
        
        # Calculate the error rate (weighted error)
        err = np.sum(sample_weights * (y_pred != y_train)) / np.sum(sample_weights)
        
        # Compute the alpha (classifier weight)
        alpha = 0.5 * np.log((1 - err) / max(err, 1e-10))  # Avoid division by zero
        
        # Update sample weights (boost the misclassified samples)
        sample_weights = sample_weights * np.exp(-alpha * y_train * y_pred)
        sample_weights /= np.sum(sample_weights)  # Normalize weights
        
        classifiers.append(clf)
        alphas.append(alpha)
    
    return classifiers, alphas

# Train AdaBoost model
classifiers, alphas = adaboost(X_train, y_train, n_estimators)

# Function to predict using AdaBoost
def predict(X, classifiers, alphas):
    predictions = np.zeros(len(X))
    for clf, alpha in zip(classifiers, alphas):
        y_pred = clf.predict(X)
        predictions += alpha * y_pred  # Weighted sum of predictions
    
    return np.sign(predictions)  # Return sign of the weighted sum

# Predict on test data
y_pred = predict(X_test, classifiers, alphas)

# Evaluate the model
accuracy = accuracy_score(y_test, y_pred)
conf_matrix = confusion_matrix(y_test, y_pred)

print("Accuracy:", accuracy)
print("Confusion Matrix:\n", conf_matrix)
