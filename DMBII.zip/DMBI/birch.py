# birch.py
import csv
import numpy as np
from collections import defaultdict

class Birch:
    def __init__(self, threshold=0.5, branching_factor=50):
        self.threshold = threshold
        self.branching_factor = branching_factor
        self.clusters = []

    def fit(self, X):
        for point in X:
            found_cluster = False
            for cluster in self.clusters:
                if np.linalg.norm(cluster["center"] - point) <= self.threshold:
                    cluster["points"].append(point)
                    cluster["center"] = np.mean(cluster["points"], axis=0)
                    found_cluster = True
                    break
            if not found_cluster:
                if len(self.clusters) < self.branching_factor:
                    self.clusters.append({"center": point, "points": [point]})

    def predict(self, X):
        return [self._predict_point(x) for x in X]

    def _predict_point(self, x):
        closest_cluster = min(self.clusters, key=lambda c: np.linalg.norm(c["center"] - x))
        return self._get_cluster_index(closest_cluster)

    def _get_cluster_index(self, closest_cluster):
        # Find the cluster index by comparing the center (using np.array for accurate comparison)
        return next(i for i, cluster in enumerate(self.clusters) if np.array_equal(cluster["center"], closest_cluster["center"]))

def load_csv(filename):
    X = []
    with open(filename, 'r') as f:
        reader = csv.reader(f)
        for row in reader:
            X.append(list(map(float, row)))
    return np.array(X)

if __name__ == "__main__":
    filename = "birch.csv"  # CSV file in the same directory
    X = load_csv(filename)
    model = Birch()
    model.fit(X)
    labels = model.predict(X)
    print("Predicted labels:", labels)
